#!/usr/bin/env python3
"""Small independent, deterministic PCM acceptance; stdlib and synthetic bytes only.

The target source is imported read-only. All fixture/output paths are under a new
output directory. No package test helpers are imported. No network is used.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import inspect
import json
import math
import os
import platform
from pathlib import Path
import struct
import subprocess
import sys
import time

sys.dont_write_bytecode = True
GUID = bytes.fromhex("0100000000001000800000aa00389b71")
SEED_POLICY = "No randomness: fixed integer sequences, 16 frames at 8000 Hz."


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def tree_manifest(root):
    return {p.relative_to(root).as_posix(): digest(p.read_bytes())
            for p in sorted(root.rglob("*")) if p.is_file()}


def chunk(kind, data):
    return kind + struct.pack("<I", len(data)) + data + (b"\0" if len(data) % 2 else b"")


def riff(chunks):
    body = b"WAVE" + b"".join(chunks)
    return b"RIFF" + struct.pack("<I", len(body)) + body


def format_chunk(width=2, channels=1, *, tag=1, align=None, byte_rate=None,
                 extension=b""):
    alignment = width * channels if align is None else align
    rate = 8000 * alignment if byte_rate is None else byte_rate
    return chunk(b"fmt ", struct.pack("<HHIIHH", tag, channels, 8000,
                                      rate, alignment, width * 8) + extension)


def samples(width, channels):
    bound = 1 << (width * 8 - 1)
    pattern = [0, 1, -1, bound // 2, -bound // 2, bound - 1, -bound, 7]
    return [pattern[(frame + channel * 3) % len(pattern)]
            for frame in range(16) for channel in range(channels)]


def encode(values, width):
    if width == 1:
        return bytes(value + 128 for value in values)
    return b"".join(value.to_bytes(width, "little", signed=True) for value in values)


def expected_metrics(raw, width, channels, values):
    return {"sha256": digest(raw), "size_bytes": len(raw), "sample_rate": 8000,
            "channels": channels, "sample_width_bytes": width,
            "frames": len(values) // channels,
            "duration_seconds": (len(values) // channels) / 8000,
            "peak_integer": max(abs(v) for v in values),
            "rms_integer": math.sqrt(sum(v * v for v in values) / len(values)),
            "finite_samples": True, "integrity": "VALID_INTEGER_PCM"}


def cases():
    result = []
    def valid(name, width=2, channels=1, fmt=None, prefix=()):
        values = samples(width, channels)
        raw = riff([*(prefix or ()), fmt or format_chunk(width, channels),
                    chunk(b"data", encode(values, width))])
        result.append({"name": name, "raw": raw, "expectation": {},
                       "expected": {"accepted": True,
                                    "metrics": expected_metrics(raw, width, channels, values)}})
        return raw

    def invalid(name, raw, reason, expectation=None):
        result.append({"name": name, "raw": raw, "expectation": expectation or {},
                       "expected": {"accepted": False, "reason": reason}})

    for width in (1, 2, 3, 4):
        for channels in (1, 2):
            valid(f"pcm_{width * 8}bit_{channels}ch", width, channels)
    valid("pcm_fmt18_zero_extension", fmt=format_chunk(extension=b"\0\0"))
    valid("extensible_mono16", fmt=format_chunk(tag=65534,
          extension=struct.pack("<HHI", 22, 16, 1) + GUID))
    valid("extensible_stereo24", 3, 2, fmt=format_chunk(3, 2, tag=65534,
          extension=struct.pack("<HHI", 22, 24, 3) + GUID))
    valid("unknown_odd_chunk_padded", prefix=[chunk(b"JUNK", b"abc")])
    for width in (1, 2, 3, 4):
        raw = riff([format_chunk(width), chunk(b"data", encode([0] * 16, width))])
        invalid(f"silence_{width * 8}bit", raw, "silent_pcm")
    data = chunk(b"data", encode(samples(2, 1), 2))
    base = riff([format_chunk(), data])
    invalid("bad_block_alignment", riff([format_chunk(align=1), data]), "inconsistent_block_alignment")
    invalid("bad_byte_rate", riff([format_chunk(byte_rate=1), data]), "inconsistent_byte_rate")
    invalid("partial_stereo_frame", riff([format_chunk(2, 2), data[:-2]]), "truncated_or_unpadded_chunk")
    invalid("stereo_unaligned_data", riff([format_chunk(2, 2), chunk(b"data", b"\1\0" * 17)]), "incomplete_frames")
    invalid("wrong_riff_length", base[:4] + struct.pack("<I", len(base) - 7) + base[8:], "riff_size_mismatch")
    invalid("wrong_container", b"RIFX" + base[4:], "unsupported_container")
    invalid("duplicate_format", riff([format_chunk(), format_chunk(), data]), "ambiguous_format")
    invalid("duplicate_data", riff([format_chunk(), data, data]), "ambiguous_data")
    invalid("reduced_valid_bits", riff([format_chunk(tag=65534,
            extension=struct.pack("<HHI", 22, 12, 1) + GUID), data]), "unsupported_reduced_valid_bits")
    invalid("channel_mask_mismatch", riff([format_chunk(tag=65534,
            extension=struct.pack("<HHI", 22, 16, 3) + GUID), data]), "inconsistent_channel_mask")
    invalid("float_encoding_tag", riff([format_chunk(tag=3), data]), "unsupported_encoding")
    invalid("expected_rate_mismatch", base, "unexpected_format", {"sample_rate": 16000})
    invalid("expected_channels_mismatch", base, "unexpected_format", {"channels": 2})
    invalid("shorter_than_default_duration", riff([format_chunk(), chunk(b"data", b"\1\0")]), "duration_outside_bounds")
    return result


def same(expected, actual):
    if set(expected) != set(actual):
        return False
    for key, value in expected.items():
        candidate = actual[key]
        if isinstance(value, dict):
            if not isinstance(candidate, dict) or not same(value, candidate):
                return False
        elif isinstance(value, float):
            if not isinstance(candidate, (float, int)) or not math.isclose(value, candidate, rel_tol=1e-12, abs_tol=1e-12):
                return False
        elif type(value) is not type(candidate) or value != candidate:
            return False
    return True


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    source = args.source.resolve(strict=True)
    output = args.output.resolve()
    if output == source or source in output.parents:
        raise SystemExit("Output must be outside the read-only source tree.")
    if output.exists():
        raise SystemExit("Output must be a new directory; refusing to overwrite.")
    output.mkdir(parents=True)
    (output / "fixtures").mkdir()
    before = tree_manifest(source)
    target = source / "qa_lab" / "audio_pcm.py"
    spec = importlib.util.spec_from_file_location("audio_acceptance_target", target)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    defaults = str(inspect.signature(module.validate_pcm))
    started = time.time()
    specs = cases()
    observed = []
    for case in specs:
        (output / "fixtures" / (case["name"] + ".wav")).write_bytes(case["raw"])
    for repeat in (1, 2):
        for case in specs:
            try:
                actual = {"accepted": True,
                          "metrics": module.validate_pcm(case["raw"], **case["expectation"])}
            except module.AudioContractError as exc:
                actual = {"accepted": False, "reason": str(exc)}
            except Exception as exc:
                actual = {"unexpected_error": type(exc).__name__, "message": str(exc)}
            row = {"repeat": repeat, "name": case["name"],
                   "fixture_sha256": digest(case["raw"]), "fixture_size": len(case["raw"]),
                   "expectation": case["expectation"], "expected": case["expected"],
                   "actual": actual, "passed": same(case["expected"], actual)}
            observed.append(row)
    cli_rows = []
    env = os.environ.copy()
    env.update(PYTHONDONTWRITEBYTECODE="1", PYTHONPATH=str(source))
    for repeat in (1, 2):
        for name, expected_code, expected_status, options in (
            ("pcm_16bit_2ch", 0, "PASSED", []),
            ("silence_16bit", 1, "FAILED", []),
            ("pcm_16bit_2ch", 1, "FAILED", ["--channels", "1"]),
        ):
            command = [sys.executable, "-B", "-W", "error::ResourceWarning", "-m", "qa_lab.audio_pcm",
                       "--wav", str(output / "fixtures" / (name + ".wav")), *options]
            proc = subprocess.run(command, cwd=source, env=env, text=True,
                                  capture_output=True, timeout=10)
            try:
                decoded = json.loads(proc.stdout)
            except Exception:
                decoded = {}
            expected_reason = ("silent_pcm" if name.startswith("silence") else
                               "unexpected_format" if options else None)
            expected_wav = next((case["expected"]["metrics"] for case in specs
                                 if case["name"] == name and case["expected"]["accepted"]), None)
            passed = (proc.returncode == expected_code and decoded.get("status") == expected_status
                      and decoded.get("scope") == "offline-integer-pcm-integrity"
                      and decoded.get("authority") == "execution-evidence-only"
                      and decoded.get("production_accepted") is False
                      and decoded.get("asr_tested") is False
                      and decoded.get("tts_quality_tested") is False
                      and proc.stderr == "")
            if expected_reason:
                passed = passed and decoded.get("reason") == expected_reason
            else:
                passed = passed and same(expected_wav, decoded.get("wav", {}))
            cli_rows.append({"repeat": repeat, "name": name, "options": options,
                             "command": command, "expected_exit": expected_code,
                             "actual_exit": proc.returncode, "stdout": proc.stdout,
                             "stderr": proc.stderr, "passed": passed})
    n = len(specs)
    deterministic = all(observed[i]["actual"] == observed[i + n]["actual"] for i in range(n))
    cli_deterministic = all(cli_rows[i]["stdout"] == cli_rows[i + 3]["stdout"]
                            and cli_rows[i]["stderr"] == cli_rows[i + 3]["stderr"]
                            and cli_rows[i]["actual_exit"] == cli_rows[i + 3]["actual_exit"]
                            for i in range(3))
    after = tree_manifest(source)
    fixtures_manifest = tree_manifest(output / "fixtures")
    expected_fixture_manifest = {case["name"] + ".wav": digest(case["raw"]) for case in specs}
    defaults_unchanged = defaults == str(inspect.signature(module.validate_pcm))
    summary = {"schema_version": "synthetic-audio-acceptance-1.0",
               "status": "PASSED" if all(row["passed"] for row in observed + cli_rows)
               and deterministic and cli_deterministic and before == after
               and defaults_unchanged
               and fixtures_manifest == expected_fixture_manifest else "FAILED",
               "synthetic_only": True, "network_used": False,
               "generator": SEED_POLICY, "python": sys.version,
               "python_executable": sys.executable, "platform": platform.platform(),
               "source_root": str(source), "audio_pcm_sha256": digest(target.read_bytes()),
               "harness_sha256": digest(Path(__file__).read_bytes()),
               "source_unchanged": before == after, "source_manifest_before": before,
               "source_manifest_after": after,
               "defaults": defaults,
               "defaults_unchanged": defaults_unchanged,
               "distinct_api_cases": n, "api_executions": len(observed),
               "api_passed": sum(row["passed"] for row in observed),
               "distinct_cli_cases": 3, "cli_executions": len(cli_rows),
               "cli_passed": sum(row["passed"] for row in cli_rows),
               "repeats": 2, "deterministic_api_outputs": deterministic,
               "deterministic_cli_outputs": cli_deterministic,
               "fixtures_unchanged_after_validation": fixtures_manifest == expected_fixture_manifest,
               "fixture_manifest": fixtures_manifest,
               "total_fixture_bytes": sum(len(case["raw"]) for case in specs),
               "max_fixture_bytes": max(len(case["raw"]) for case in specs),
               "elapsed_seconds": time.time() - started,
               "production_accepted": False,
               "scope": "Small synthetic integer-PCM acceptance; no legacy runtime, deployed worker or speech quality claim."}
    (output / "results.json").write_text(json.dumps({"summary": summary, "api": observed,
                                                   "cli": cli_rows}, indent=2) + "\n")
    (output / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    lines = [f"repeat={row['repeat']} case={row['name']} {'PASS' if row['passed'] else 'FAIL'}"
             for row in observed]
    lines.extend(f"cli repeat={row['repeat']} case={row['name']} options={row['options']} "
                 f"exit={row['actual_exit']} {'PASS' if row['passed'] else 'FAIL'}"
                 for row in cli_rows)
    lines.append(json.dumps(summary, sort_keys=True))
    (output / "run.log").write_text("\n".join(lines) + "\n")
    print(json.dumps({key: summary[key] for key in
                      ("status", "distinct_api_cases", "api_executions", "api_passed",
                       "distinct_cli_cases", "cli_executions", "cli_passed",
                       "deterministic_api_outputs", "deterministic_cli_outputs",
                       "source_unchanged", "fixtures_unchanged_after_validation",
                       "total_fixture_bytes", "max_fixture_bytes", "elapsed_seconds")}, indent=2))
    return 0 if summary["status"] == "PASSED" else 1


if __name__ == "__main__":
    raise SystemExit(main())
