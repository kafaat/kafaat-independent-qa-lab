#!/usr/bin/env python3
"""Replay the supplied PCM acceptance twice without modifying its package.

Standard library only; all tests use synthetic fixtures. Run from any directory:
  python acceptance_replay.py --package ./package --out ./fresh-replay
An existing output directory is rejected. The runner does not change source,
defaults, any repository, service or deployed recipe.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time
from datetime import datetime, timezone


CHILD = r'''
import gc, hashlib, inspect, json, os, sys, unittest
from pathlib import Path
sys.dont_write_bytecode = True
sys.path[:0] = [str(Path.cwd()), str(Path.cwd() / 'tests')]
unraisable = []
sys.unraisablehook = lambda e: unraisable.append(type(e.exc_value).__name__)
from qa_lab import audio_pcm
from audio_fixtures import cases

def defaults():
    return {'signature': str(inspect.signature(audio_pcm.validate_pcm)),
            'MAX_BYTES': audio_pcm.MAX_BYTES, 'MAX_CHUNKS': audio_pcm.MAX_CHUNKS}

before_defaults = defaults()
class Result(unittest.TextTestResult):
    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self.rows = []
        self.subtests = 0
    def addSuccess(self, test):
        super().addSuccess(test)
        self.rows.append({'id': test.id(), 'status': 'PASSED'})
    def addFailure(self, test, err):
        super().addFailure(test, err)
        self.rows.append({'id': test.id(), 'status': 'FAILED'})
    def addError(self, test, err):
        super().addError(test, err)
        self.rows.append({'id': test.id(), 'status': 'ERROR'})
    def addSkip(self, test, reason):
        super().addSkip(test, reason)
        self.rows.append({'id': test.id(), 'status': 'SKIPPED', 'reason': reason})
    def addSubTest(self, test, subtest, err):
        super().addSubTest(test, subtest, err)
        self.subtests += 1

suite = unittest.defaultTestLoader.discover('tests', pattern='test_audio_*.py')
result = unittest.TextTestRunner(verbosity=2, resultclass=Result).run(suite)
records = []
for c in cases():
    row = {'id': c['id'], 'group': c['group'], 'size_bytes': len(c['raw']),
           'sha256': hashlib.sha256(c['raw']).hexdigest(), 'options': c['options'],
           'expected_accepted': c['accepted']}
    try:
        row['result'] = {'decision': 'ACCEPTED', 'metrics': audio_pcm.validate_pcm(c['raw'], **c['options'])}
    except audio_pcm.AudioContractError as e:
        row['result'] = {'decision': 'REJECTED', 'reason': str(e)}
    records.append(row)
gc.collect()
ok = (result.wasSuccessful() and result.testsRun == 76 and not result.skipped
      and not unraisable and defaults() == before_defaults
      and all((r['result']['decision'] == 'ACCEPTED') == r['expected_accepted'] for r in records))
report = {'status': 'PASSED' if ok else 'FAILED', 'python': sys.version,
          'executable': sys.executable, 'tests_run': result.testsRun,
          'failures': len(result.failures), 'errors': len(result.errors),
          'skips': len(result.skipped), 'unraisable_errors': unraisable,
          'subtests': result.subtests, 'defaults_before': before_defaults,
          'defaults_after': defaults(), 'test_results': result.rows,
          'synthetic_cases': records,
          'source_path': str(Path(audio_pcm.__file__).resolve()),
          'source_sha256': hashlib.sha256(Path(audio_pcm.__file__).read_bytes()).hexdigest(),
          'production_accepted': False, 'legacy_executed': False}
print(json.dumps(report, sort_keys=True, allow_nan=False))
raise SystemExit(0 if ok else 1)
'''


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def canonical(value) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def snapshot(root: Path) -> dict:
    result = {}
    for p in sorted(root.rglob('*')):
        if p.is_file():
            st = p.stat()
            result[str(p.relative_to(root))] = {
                'sha256': digest(p.read_bytes()), 'size_bytes': st.st_size,
                'mtime_ns': st.st_mtime_ns, 'mode': st.st_mode & 0o7777,
            }
    return result


def write_json(path: Path, value) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n')


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--package', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    package = args.package.resolve(strict=True)
    out = args.out.resolve()
    if out == package or package in out.parents:
        parser.error('Output must be outside the input package')
    out.mkdir(parents=True, exist_ok=False)
    source = package / 'source'
    before = snapshot(package)
    write_json(out / 'package_before.json', before)
    manifest_rows = []
    for line in (package / 'SHA256SUMS.sha256').read_text().splitlines():
        expected, name = line.split(maxsplit=1)
        name = name.lstrip('*')
        p = (package / name).resolve(strict=True)
        if package not in p.parents:
            raise ValueError('Unsafe manifest path')
        actual = digest(p.read_bytes())
        manifest_rows.append({'path': name, 'expected': expected,
                              'actual': actual, 'matches': actual == expected})
    listed = {r['path'] for r in manifest_rows}
    coverage = set(before) - {'SHA256SUMS.sha256'} == listed
    integrity = all(r['matches'] for r in manifest_rows) and coverage and len(listed) == len(manifest_rows)
    write_json(out / 'input_integrity.json', {
        'status': 'PASSED' if integrity else 'FAILED', 'coverage_complete': coverage,
        'manifest_entries': len(manifest_rows), 'package_files': len(before), 'files': manifest_rows})
    if not integrity:
        raise SystemExit('Package integrity failed; tests not executed')
    runs = []
    started = datetime.now(timezone.utc).isoformat()
    for i in (1, 2):
        temp = out / f'temp-{i}'
        temp.mkdir()
        env = dict(os.environ)
        env.update({'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONHASHSEED': '0',
                    'PYTHONPATH': os.pathsep.join([str(source), str(source / 'tests')]),
                    'PYTHONNOUSERSITE': '1', 'TMPDIR': str(temp), 'LC_ALL': 'C.UTF-8'})
        command = [sys.executable, '-B', '-W', 'error::ResourceWarning', '-c', CHILD]
        start = time.monotonic()
        proc = subprocess.run(command, cwd=source, env=env, capture_output=True,
                              text=True, timeout=30, check=False)
        elapsed = time.monotonic() - start
        (out / f'run-{i}.log').write_text(proc.stderr)
        (out / f'run-{i}.stdout.json').write_text(proc.stdout)
        try:
            data = json.loads(proc.stdout)
        except json.JSONDecodeError:
            data = {'status': 'FAILED', 'reason': 'child_report_invalid'}
        data.update({'exit_code': proc.returncode, 'elapsed_seconds': elapsed,
                     'temporary_entries_after': sorted(str(p.relative_to(temp)) for p in temp.rglob('*'))})
        write_json(out / f'run-{i}.json', data)
        runs.append(data)
    after = snapshot(package)
    write_json(out / 'package_after.json', after)
    stable_keys = ['tests_run', 'failures', 'errors', 'skips', 'unraisable_errors',
                   'subtests', 'defaults_before', 'defaults_after', 'test_results',
                   'synthetic_cases', 'source_sha256']
    normalized = [{k: run.get(k) for k in stable_keys} for run in runs]
    stable = normalized[0] == normalized[1]
    unchanged = before == after
    ok = all(r['status'] == 'PASSED' and r['exit_code'] == 0 and not r['temporary_entries_after'] for r in runs)
    ok = ok and unchanged and stable
    summary = {
        'schema_version': 'limited-synthetic-pcm-replay-1.0',
        'status': 'PASSED' if ok else 'FAILED',
        'started_utc': started, 'finished_utc': datetime.now(timezone.utc).isoformat(),
        'python': sys.version, 'platform': platform.platform(),
        'interpreter_sha256': digest(Path(sys.executable).read_bytes()),
        'runner_sha256': digest(Path(__file__).read_bytes()),
        'source_sha256': runs[0].get('source_sha256'),
        'package_files': len(before), 'verified_manifest_entries': len(manifest_rows),
        'tests_per_run': [r.get('tests_run') for r in runs],
        'run_seconds': [r['elapsed_seconds'] for r in runs],
        'package_content_mode_mtime_unchanged': unchanged,
        'source_tree_file_set_unchanged': set(before) == set(after),
        'deterministic_test_and_fixture_results': stable,
        'normalized_result_sha256': [digest(canonical(x)) for x in normalized],
        'defaults_unchanged': all(r.get('defaults_before') == r.get('defaults_after') for r in runs),
        'strict_resource_warnings': True, 'network_needed': False,
        'legacy_source_executed': False, 'historical_ci_reexecuted': False,
        'production_accepted': False, 'deployed_profile_comparison': 'NOT_RUN',
        'full_audio_profile_status': 'PARTIAL',
        'scope': 'Supplied archived PCM module and deterministic synthetic fixtures only',
        'reproduce': 'python acceptance_replay.py --package ./package --out ./fresh-replay',
    }
    write_json(out / 'summary.json', summary)
    print(json.dumps(summary, indent=2))
    return 0 if ok else 1


if __name__ == '__main__':
    raise SystemExit(main())
